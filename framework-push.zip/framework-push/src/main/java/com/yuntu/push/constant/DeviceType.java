package com.yuntu.push.constant;

public enum DeviceType{
    all,
    android,
    ios
}